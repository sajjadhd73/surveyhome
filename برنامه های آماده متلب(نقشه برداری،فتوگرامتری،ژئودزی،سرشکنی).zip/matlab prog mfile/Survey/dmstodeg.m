function deg = dmstodeg(dms)

deg = dms(:,1)+(dms(:,2)+(dms(:,3)/60))/60;