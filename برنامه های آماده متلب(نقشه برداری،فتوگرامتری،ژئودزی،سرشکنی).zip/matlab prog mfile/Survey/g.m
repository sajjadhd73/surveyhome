function G = g(angl,g0)

G = zeros(size(angl,1),1);
G_R = zeros(size(angl,1),1);
G(1) = g0;

for i = 1:size(angl,1)-1
    
    if G(i) < 180
    
        G_R(i) = G(i) + 180;

    else
        G_R(i) = G(i) - 180;
    end
    
    G(i+1) = G_R(i) + angl(i+1);
        
    if G(i+1) <= 360
        
        i = i + 1;
        
    else
        
        G(i+1) = G(i+1) - 360;
        i = i + 1;
        
    end
end

end