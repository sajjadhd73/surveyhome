function y = az(x1,y1,x2,y2)

%
% AZ Calculate Azimuth of a direction
%
% AZ(Xa,Ya,Xb,Yb): compute the Azimuth of the AB-direction
%
% AZ(Xa,Ya) Compute Azimuth of OA Direction; where O is the 
% Origin of the Net.


if nargin == 4
            
       if ((x2-x1) >= 0 & (y2-y1) >= 0)
           y = atand(abs((x2-x1)/(y2-y1)));
       elseif ((x2-x1) >= 0 & (y2-y1) <= 0)
           y = 180 - atand(abs((x2-x1)/(y2-y1)));
       elseif ((x2-x1) <= 0 & (y2-y1) <= 0)
           y = 180 + atand(abs((x2-x1)/(y2-y1)));
       else
           y = 360 - atand(abs((x2-x1)/(y2-y1)));
       end
       
elseif nargin == 2

       if (x1 >= 0 & y1 >= 0)
           y = atand(abs(x1/y1));
       elseif (x1 >= 0 & y1 <= 0)
           y = 180 - atand(abs(x1/y1));
       elseif (x1 <= 0 & y1 <= 0)
           y = 180 + atand(abs(x1/y1));
       else
           y = 360 - atand(abs(x1/y1));
       end
              
else
    error('Unexpected situation')
end
