function m = insect1(A, B, alfa, beta)

% in tabe bar asase neshanvandhaye vorudi va be raveshe taghato, mokhtasate
% noghteye majhule 'm' ra mohasebe mikonad.
%
% do nokteye mohem dar estefade az in tabe vujud darad: 1. hatman zavayaye 
% 'alfa' va 'beta' bayad be surate DMS vared shavan. 2. tartibe vurude 
% neshanvandhaye 'A' va 'B' mohem ast. in se noghte, yani 'A', 'B', va 'm' 
% bayad be surate pad sa'at gard hamdigr ra bebinand!
%
%
% in tabe baraye estefade dar ketabe 'matlab dar khedmate naghshebardari'
% neveshte shode ast.
%

x_m = (A(1)*cotd(dmstodeg(beta)) + B(1)*cotd(dmstodeg(alfa)) - (B(2) - A(2)))/...
      (cotd(dmstodeg(alfa)) + cotd(dmstodeg(beta)));
  
y_m = (A(2)*cotd(dmstodeg(beta)) + B(2)*cotd(dmstodeg(alfa)) + (B(1) - A(1)))/...
      (cotd(dmstodeg(alfa)) + cotd(dmstodeg(beta)));
  
  m = [x_m, y_m];