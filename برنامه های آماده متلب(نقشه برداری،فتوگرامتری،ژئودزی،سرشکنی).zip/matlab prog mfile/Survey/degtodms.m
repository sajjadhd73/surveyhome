function dms = degtodms(deg)

d = fix(deg);
m = fix((deg - d)*60);
s = fix(((deg - d)*60 - m)*60);

dms = [d m s];