function h_c = level(BS,FS,H_start,H_end,dist,k)

h = zeros(size(BS,1),1);
h(1) = H_start;

for i = 1:size(BS,1)
    
    h(i+1) = h(i) + (BS(i)/1000) - (FS(i)/1000);
    i = i+1;
    
end

e = h(end) - H_end;
e_max = (k*sqrt(dist))/1000;

if e <= e_max
    
    c = zeros(size(h,1),1);
    
    for i = 2:size(h,1)
        
        c(i) = (-e*(i-1))/(size(h,1)-1);
        i = i+1;
        
    end
    
    h_c = h + c;
           
else
    
    disp('closed error is too large!')
    
end