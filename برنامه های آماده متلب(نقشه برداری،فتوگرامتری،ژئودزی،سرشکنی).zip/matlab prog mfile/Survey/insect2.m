function M = insect2(A, B, AZ_AM, AZ_BM)

% M = insect2(A, B, AZ_AM, AZ_BM) bar asase neshanvandhaye vorudi va be 
% raveshe taghato, mokhtasate noghteye majhule 'm' ra mohasebe mikonad.
%
% do nokteye mohem dar estefade az in tabe vujud darad: 1. hatman zavayaye 
% 'alfa' va 'beta' bayad be surate DMS vared shavan. 2. tartibe vurude 
% neshanvandhaye 'A' va 'B' mohem ast. in se noghte, yani 'A', 'B', va 'm' 
% bayad be surate pad sa'at gard hamdigr ra bebinand!
%
% in tabe baraye estefade dar ketabe 'matlab dar khedmate naghshebardari'
% neveshte shode ast
%

x_m = (A(1)*cotd(dmstodeg(AZ_AM)) - B(1)*cotd(dmstodeg(AZ_BM)) + (B(2) - A(2)))/...
      (cotd(dmstodeg(AZ_AM)) - cotd(dmstodeg(AZ_BM)));
  
y_m = ((x_m - A(1))*cotd(dmstodeg(AZ_AM))) + A(2);
  
  M = [x_m, y_m];