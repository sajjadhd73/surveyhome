function X = trav(dist,angle,x0,y0,az0,ins_fac)

alfa = dmstodeg(angle);

e_alfa = sum(alfa) - (size(alfa,1)-2)*180;
e_max = dmstodeg([0 0 2.5*ins_fac*sqrt(3)]);

if e_alfa <= e_max
    
    c_alfa = degtodms(alfa - (e_alfa / size(alfa,1)));
    
    c_alfa = alfa - (e_alfa / size(alfa,1));
    azimuth = g(alfa,dmstodeg(az0));

    delta_x = dist .* sind(azimuth);
    delta_y = dist .* cosd(azimuth);

    e_x = sum(delta_x);
    e_y = sum(delta_y);

    sigma_abs_delta_x = sum(abs(delta_x));
    sigma_abs_delta_y = sum(abs(delta_y));

    c_x = (e_x .* abs(delta_x)) ./ sigma_abs_delta_x;
    c_y = (e_y .* abs(delta_y)) ./ sigma_abs_delta_y;

    x = zeros(size(dist,1),1);
    y = zeros(size(dist,1),1);

    x(1) = x0;
    y(1) = y0;

    for i = 2:size(dist,1)
    
        x(i) = x(i-1) + delta_x(i-1);
        y(i) = y(i-1) + delta_y(i-1);
        
        i = i + 1;
    
    end
    
    
    x_c(1) = x(1);
    y_c(1) = y(1);
    
    for i = 2:size(dist,1)
        
        x_c(i) = x(i) + c_x(i-1);
        y_c(i) = y(i) + c_y(i-1);
        
        i = i + 1;
    
    end
    
    X = [x_c y_c];
    plot(x_c([1:end,1]),y_c([1:end,1]),'b--o')
    
else
    
    disp('Angular condition is not valid!')
           
end

