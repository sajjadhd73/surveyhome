function r_CT = it2ct(r_IT,p)
%
% in this function
%
% r_IT: point's coordinate in IT coordinate system
%    p: pole's coordinate in IT coordinate system
%
% r_CT: point's coordinate in CT coordinate system
%
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.
xp_cap = p(1) / 6356752;
yp_cap = p(2) / 6356752;

R2_xp_cap = [1 0 xp_cap;0 1 0;-xp_cap 0 1];
R1_yp_cap = [1 0 0;0 1 -yp_cap;0 yp_cap 1];

r_CT = R2_xp_cap*R1_yp_cap*r_IT';