function [lambda_phi h] = xyz2sphr(x,y,z,R)

%
% in this function
%    xyz: point's coordinate in cartesian
%      R: is Rsdiuse of refrence sphere
%
% lambda: is longitude of point (in dms)
%    phi: is latitude of point (in dms)
%      h: is hieght of point (in meter)
% 
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

h = norm([x,y,z],2) - R;
phi = degtodms(asind(z/(R + h)));

if (x >= 0 & y >= 0)
    
    k = 0;
    
elseif (x > 0 & y < 0)
    
    K = 1;
    
elseif (x < 0 & y < 0)
    
    K = 1;
    
elseif (x < 0 & y > 0)
    
    k = 2;
    
end

lambda = degtodms(atand(y/x) + k * 180);

lambda_phi = [lambda; phi];