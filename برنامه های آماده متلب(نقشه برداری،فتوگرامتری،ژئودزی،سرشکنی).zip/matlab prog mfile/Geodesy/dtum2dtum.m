function [phi_lambda h] = dtum2dtum(dtumin,dtumout,STNin)

%
% in this function
%
%  dtumin: a coloumn vector as [x0; y0; z0; a; f] of input datume
% dtumout: a coloumn vector as [x0; y0; z0; a; f] output datume
%   STNin: STatioN coordinate in input datume
%
% phi_lambda: latitude & longitude of station in output datume
%          h: height of station in output datume
%
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

dx = dtumout(1) - dtumin(1);
dy = dtumout(2) - dtumin(2);
dz = dtumout(3) - dtumin(3);

delta_xyz = [dx; dy; dz];

da = dtumout(4) - dtumin(4);
df = dtumout(5) - dtumin(5);

delta_af = [da; df];

e2 = dtumin(5) * (2 - dtumin(5));
N = dtumin(4) / sqrt(1 - e2 * sind(STNin(1))^2);
M = dtumin(4)*(1 - e2) / sqrt((1 - e2 * sind(STNin(1))^2)^3);

J(1,1) = -sind(STNin(1))*cosd(STNin(2)) / (M + STNin(3));
J(1,2) = -sind(STNin(1))*sind(STNin(2)) / (M + STNin(3));
J(1,3) = cosd(STNin(1)) / (M + STNin(3));
J(2,1) = -sind(STNin(2)) / ((M + STNin(3))*cosd(STNin(1)));
J(2,2) = cosd(STNin(2)) / ((N + STNin(3))*cosd(STNin(1)));
J(2,3) = 0;
J(3,1) = cosd(STNin(1)) * cosd(STNin(2));
J(3,2) = cosd(STNin(1)) * sind(STNin(2));
J(3,3) = sind(STNin(1));

JE(1,1) = N*cosd(STNin(1))*cosd(STNin(2)) / dtumin(4);
JE(2,1) = N*cosd(STNin(1))*sind(STNin(2)) / dtumin(4);
JE(2,2) = M*sind(STNin(1))^2*cosd(STNin(1))*sind(STNin(2)) / (1 - dtumin(5));
JE(1,2) = M*sind(STNin(1))^2*cosd(STNin(1))*cosd(STNin(2)) / (1 - dtumin(5));
JE(3,1) = N*(1 - dtumin(5))^2*sind(STNin(1)) / dtumin(4);
JE(3,2) = (M*sind(STNin(1))^2 - 2*N)*sind(STNin(1)) / (1 - dtumin(5));

STNout = -J*([dx;dy;dz] + JE*[da;df]);

phiout = degtodms((STNout(1)*180/pi) + STNin(1));
lambdaout = degtodms((STNout(2)*180/pi) + STNin(2));
hout = STNout(3)+STNin(3);

phi_lambda = [phiout; lambdaout];
h = hout;