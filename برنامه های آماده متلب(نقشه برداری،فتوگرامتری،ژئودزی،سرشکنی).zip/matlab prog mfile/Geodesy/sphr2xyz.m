function xyz = sphr2xyz(lambda,phi,h,R)

%
% in this function
%
% lambda: is longitude of point (in dms)
%    phi: is latitude of point (in dms)
%      h: is hieght of point (in meter)
%      R: is Rsdiuse of refrence sphere
% 
%    xyz: point's coordinate in cartesian
%
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

if nargin == 4

    x = (R + h) * cosd(dmstodeg(phi)) * cosd(dmstodeg(lambda));
    y = (R + h) * cosd(dmstodeg(phi)) * sind(dmstodeg(lambda));
    z = (R + h) * sind(dmstodeg(phi));

    xyz = [x y z];
    
elseif nargin == 3
    
    x = (6371000 + h) * cosd(dmstodeg(phi)) * cosd(dmstodeg(lambda));
    y = (6371000 + h) * cosd(dmstodeg(phi)) * sind(dmstodeg(lambda));
    z = (6371000 + h) * sind(dmstodeg(phi));

    xyz = [x y z];
    
else
    
    error('     Number of arguments is not correct!')
    
end