clc; clear; format short g;

xy = [0 0; 100 0];
 L = [60; 60.02; 100.1];
 
QL = eye(3);
 W = inv(QL);
 
delta_0 = [50.02; 86.637];

syms xc yc L1 L2 L3

F(1) = yc - xy(1,2) - L3*cos((az(xy(1,1),xy(1,2),xy(2,1),xy(2,2))-L1)*pi/180);
F(2) = L3*sin((L1 + L2)*pi/180) - sqrt((xy(1,1)-xy(2,1))^2 + (xy(1,2)-xy(2,2))^2)*sin(L2*pi/180);

AX = jacobian(F,[L1 L2 L3]);
BX = jacobian(F(1),[xc yc])';

num = 0; s = 1;

while s > 3*10^-2
    
    
    A = subs(AX,[L1 L2 L3],[L(1) L(2) L(3)]);
    B = subs(BX,[xc yc],[delta_0(1) delta_0(2)]);
    
    f = subs(-F,[L1 L2 L3 yc],[L(1) L(2) L(3) delta_0(2)]);
       
    Qe = A*QL*A';
    We = inv(Qe);
    
    N = B'*We*B;
    d_delta = inv(N)*B'*We*f';
    
    k = We*(f' - B*d_delta);
    v = QL*A'*k;
    
    L = L + v;
    delta_0 = delta_0 + d_delta;
    
    s = norm(d_delta,2);
    
    num = num + 1;
    
end

  delta_cap = delta_0
Q_delta_cap = inv(N)

 L_cap = L
QL_cap = QL - (A'*We*A - A'*We*B*Q_delta_cap*B'*We*A)

num