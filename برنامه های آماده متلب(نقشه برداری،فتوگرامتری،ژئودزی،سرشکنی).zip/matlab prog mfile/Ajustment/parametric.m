clc; clear; format short g;

L = [40 19 2; 70 30 1; 69 11 0];
L = dmstodeg(L);

syms x1 x2

F(1) = L(1) - x1;
F(2) = L(2) - x2;
F(3) = L(3) + x1 + x2 -180;

 B = double(jacobian(F,[x1 x2]));
 f = subs(-F,[x1 x2],[0 0]);
QL = eye(3);

W = inv(QL);
N = B'*W*B;
t = B'*W*f';

  delta_cap = inv(N)*t;
  delta_cap = degtodms(delta_cap)
Q_delta_cap = inv(N)