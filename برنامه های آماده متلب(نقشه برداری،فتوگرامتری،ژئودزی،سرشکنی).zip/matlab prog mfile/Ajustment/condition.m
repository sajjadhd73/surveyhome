clc; clear; format short g;

H1 = 100;

 L = [4; 2; -6.3];
QL = eye(3)*10^-3;

syms L1 L2 L3

F = L1 + L2 + L3;

A = double(jacobian(F,[L1 L2 L3]));
f = subs(-F,[L1 L2 L3],[L(1) L(2) L(3)]);

Qe = A*QL*A';
We = inv(Qe);

K = We*f';

v_cap = QL*A'*K
Q_v_cap = QL*A'*We*A*QL

L_cap = L + v_cap
Q_L_cap = QL - Q_v_cap

delta_cap = [H1 + L_cap(1); H1 + L_cap(2)]