clc; clear; format short g;

xy = [300 300; 600 250; 800 400];
 L = [360.5; 250.1; 223.5];
QL = diag([.005^2 .005^2 .005^2]);

syms xp yp

F(1) = sqrt((xp-xy(1,1))^2 + (yp-xy(1,2))^2);
F(2) = sqrt((xp-xy(2,1))^2 + (yp-xy(2,2))^2);
F(3) = sqrt((xp-xy(3,1))^2 + (yp-xy(3,2))^2);

Bx = jacobian(F,[xp yp]);

W = inv(QL);
delta_0 = [633.5795; 436.6929];

num = 0; s = 1;

while s > 10^-6
	
	L0 = subs(F,[xp yp],[delta_0(1) delta_0(2)]);
    
     B = subs(Bx,[xp yp],[delta_0(1) delta_0(2)]);
     
	dL = L - L0';
    
	 N = B'*W*B;
    
	d_delta = inv(N)*B'*W*dL;
	delta_0 = d_delta + delta_0;
    
    
    s = norm(d_delta,2);
    
    num = num + 1;
    
end

  delta_cap = delta_0
Q_delta_cap = inv(N)

num