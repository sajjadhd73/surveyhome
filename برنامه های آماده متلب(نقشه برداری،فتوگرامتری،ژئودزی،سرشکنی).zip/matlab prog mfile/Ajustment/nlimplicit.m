clc; clear; format short g;

 L = [1.9; 4.1];
y0 = 3.5;

QL = eye(2);
W = inv(QL);

syms L1 L2 y

F(1) = L1^2 - y;
F(2) = L2^2 - 4*y;

AX = jacobian(F,[L1 L2]);
BX = jacobian(F,y);

num = 0; s = 1;

while s > 10^-6
    
    A = subs(AX,[L1 L2],[L(1) L(2)]);
    B = subs(BX,[y],[y0]);
    
    f = subs(-F,[L1 L2 y],[L(1) L(2) y0]);
    
    Qe = A*QL*A';
    We = inv(Qe);
    
    N = B'*We*B;
    d_delta = inv(N)*B'*We*f';
    
    k = We*(f' - B*d_delta);
    v = QL*A'*k;
    
     L = L + v;
    y0 = y0 + d_delta;
    
    s = norm(d_delta,2);
    
    num = num + 1;
    
end

 y_cap = y0
Qy_cap = inv(N)

 L_cap = L
QL_cap = QL - (QL*A'*We*A*QL - QL*A'*We*B*Qy_cap*B'*We*A*QL)

num