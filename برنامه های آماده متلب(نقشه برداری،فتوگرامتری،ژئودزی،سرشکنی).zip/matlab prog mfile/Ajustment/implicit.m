clc; clear; format short g;

HA = 100;
 L = [4; 2; -6.3; 5];
 
QL = eye(4);
 W = inv(QL);

syms L1 L2 L3 L4 x1 x2 x3

F(1) = L1 - (x1-HA);
F(2) = L2 - (HA-x2);
F(3) = L3 - (x2-x1);
F(4) = L4 - (x3-x1);

A = double(jacobian(F,[L1 L2 L3 L4]));
B = double(jacobian(F,[x1 x2 x3]));

f = -L;

Qe = A*QL*A';
We = inv(Qe);

N = B'*We*B;
delta_cap = inv(N)*B'*We*f
Q_delta_cap = inv(N)

k = We*(f - B*delta_cap);
v_cap = QL*A'*k
Qv_cap = QL*A'*We*A*QL - QL*A'*We*B*Q_delta_cap*B'*We*A*QL

QL_cap = QL - Qv_cap