function [fidushal_coordinate orientation_factors] = inorient(calib_fidushal,photo_fidushal,measured_point,method)



switch lower(method)
    
    case 'conformal'

        A = zeros(2*size(photo_fidushal,1),4);
        B = zeros(2*size(photo_fidushal,1),1);

        for i = 1:size(photo_fidushal,1)
    
            A(2*i-1,:) = [calib_fidushal(i,1), calib_fidushal(i,2), 1, 0];
              A(2*i,:) = [calib_fidushal(i,2), -calib_fidushal(i,1), 0, 1];
    
            B(2*i-1,:) = photo_fidushal(i,1);
              B(2*i,:) = photo_fidushal(i,2);
      
            i = i + 1;
    
        end

        orientation_factors = inv(A'*A)*A'*B;

        A = zeros(2*size(measured_point,1),4);

        for i = 1:size(measured_point,1)
    
            A(2*i-1,:) = [measured_point(i,1), measured_point(i,2), 1, 0];
              A(2*i,:) = [measured_point(i,2), -measured_point(i,1), 0, 1];
      
            i = i + 1;
      
        end

        p_coordinate = A * orientation_factors;

        fidushal_coordinate = zeros(size(measured_point,1),2);

        for i = 1:size(measured_point,1)
    
            fidushal_coordinate(i,1) = p_coordinate(2*i-1,:);
            fidushal_coordinate(i,2) = p_coordinate(2*i,:);
    
            i = i + 1;
      
        end

    case 'affine'
        
        A = zeros(2*size(photo_fidushal,1),6);
        B = zeros(2*size(photo_fidushal,1),1);

        for i = 1:size(photo_fidushal,1)
    
            A(2*i-1,:) = [calib_fidushal(i,1), calib_fidushal(i,2), 0, 0, 1, 0];
            A(2*i,:) = [0, 0, calib_fidushal(i,2), -calib_fidushal(i,1), 0, 1];
    
            B(2*i-1,:) = photo_fidushal(i,1);
              B(2*i,:) = photo_fidushal(i,2);
      
            i = i + 1;
    
        end

        orientation_factors = inv(A'*A)*A'*B;

        A = zeros(2*size(measured_point,1),6);

        for i = 1:size(measured_point,1)
    
            A(2*i-1,:) = [measured_point(i,1), 0, 0, measured_point(i,2), 1, 0];
              A(2*i,:) = [0, 0, measured_point(i,2), -measured_point(i,1), 0, 1];
      
            i = i + 1;
      
        end

        p_coordinate = A * orientation_factors;

        fidushal_coordinate = zeros(size(measured_point,1),2);

        for i = 1:size(measured_point,1)
    
            fidushal_coordinate(i,1) = p_coordinate(2*i-1,:);
            fidushal_coordinate(i,2) = p_coordinate(2*i,:);
    
            i = i + 1;
      
        end
        
    case 'projective'

        A = zeros(2*size(photo_fidushal,1),8);
        B = zeros(2*size(photo_fidushal,1),1);

        for i = 1:size(photo_fidushal,1)
    
            A(2*i-1,:) = [calib_fidushal(i,1), 0, -calib_fidushal(i,1)*photo_fidushal(i,1), calib_fidushal(i,2), 0, -calib_fidushal(i,2)*photo_fidushal(i,1), 1, 0];
              A(2*i,:) = [0, calib_fidushal(i,1), -calib_fidushal(i,1)*photo_fidushal(i,2), 0, calib_fidushal(i,2), -calib_fidushal(i,2)*photo_fidushal(i,2), 0, 1];
    
            B(2*i-1,:) = photo_fidushal(i,1);
              B(2*i,:) = photo_fidushal(i,2);
      
            i = i + 1;
    
        end

        orientation_factors = inv(A'*A)*A'*B;

        A = zeros(2*size(measured_point,1),8);

        for i = 1:size(measured_point,1)
    
            A(2*i-1,:) = [measured_point(i,1), 0, -measured_point(i,1)*photo_fidushal(i,1), measured_point(i,2), 0, -measured_point(i,2)*photo_fidushal(i,1), 1, 0];
              A(2*i,:) = [0, measured_point(i,1), -measured_point(i,1)*photo_fidushal(i,2), 0, measured_point(i,2), -measured_point(i,2)*photo_fidushal(i,2), 0, 1];
    
      
            i = i + 1;
      
        end

        p_coordinate = A * orientation_factors;

        fidushal_coordinate = zeros(size(measured_point,1),2);

        for i = 1:size(measured_point,1)
    
            fidushal_coordinate(i,1) = p_coordinate(2*i-1,:);
            fidushal_coordinate(i,2) = p_coordinate(2*i,:);
    
            i = i + 1;
      
        end
        
end