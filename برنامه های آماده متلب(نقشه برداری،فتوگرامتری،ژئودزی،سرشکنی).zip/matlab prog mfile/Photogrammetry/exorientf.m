function [eoelements num] = exorientf(gcp,mphc,f,p)

%
% in this function
%
% gcp: Ground Control Points
% mphc: Measured PHoto Coordinates
% f: Focal length
% p: presission of calculation
% 
% eoelements: Exterior Orientation Elements
% num: NUMber of itrations
%
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

omega = 0; phi = 0;

ab = sqrt(((mphc(2,1)-mphc(1,1))^2)+((mphc(2,2)-mphc(1,2))^2));
AB = sqrt(((gcp(2,1)-gcp(1,1))^2)+((gcp(2,2)-gcp(1,2))^2));
 H = (f*AB) / ab;

for i = 1:size(mphc,1)
    
    A(2*i-1,:) = [mphc(i,1) mphc(i,2) 1 0];
      A(2*i,:) = [mphc(i,2) -mphc(i,1) 0 1];
    
    B(2*i-1,:) = gcp(i,1);
      B(2*i,:) = gcp(i,2);
    
end

F = inv(A'*A)*A'*B;

kapa = atand(F(2)/F(1));

Xo = F(3);
Yo = F(4);
Zo = H;

m(1,1) = cosd(phi)*cosd(kapa);
m(1,2) = cosd(omega)*sind(kapa) + sind(omega)*sind(phi)*cosd(kapa);
m(1,3) = sind(omega)*sind(kapa) - cosd(omega)*sind(phi)*cosd(kapa);
m(2,1) = -cosd(phi)*sind(kapa);
m(2,2) = cosd(omega)*cosd(kapa) - sind(omega)*sind(phi)*sind(kapa);
m(2,3) = sind(omega)*cosd(kapa) + cosd(omega)*sind(phi)*sind(kapa);
m(3,1) = sind(phi);
m(3,2) = -sind(omega)*cosd(phi);
m(3,3) = cosd(omega)*cosd(phi);

deltaX = gcp(:,1) - Xo;
deltaY = gcp(:,2) - Yo;
deltaZ = gcp(:,3) - Zo;

q = m(3,1).*deltaX + m(3,2).*deltaY + m(3,3).*deltaZ;
r = m(1,1).*deltaX + m(1,2).*deltaY + m(1,3).*deltaZ;
s = m(2,1).*deltaX + m(2,2).*deltaY + m(2,3).*deltaZ;



b11 = (f./q.^2).*(r.*(-m(3,3).*deltaY+m(3,2).*deltaZ) - q.*(-m(1,3).*deltaY + m(1,2).*deltaZ));
b12 = (f./q.^2).*(r.*(cosd(phi).*deltaX + sind(omega).*sind(phi).*deltaY - cosd(omega).*sind(phi).*deltaZ) - ...
       q.*(-sind(phi).*cosd(kapa).*deltaX + sind(omega).*cosd(phi).*cosd(kapa).*deltaY - cosd(omega).*cosd(phi).*cosd(kapa).*deltaZ));
b13 = (-f./q).*(m(2,1).*deltaX + m(2,2).*deltaY + m(2,3).*deltaZ);
b14 = (f./q.^2).*(r.*m(3,1) - q.*m(1,1));
b15 = (f./q.^2).*(r.*m(3,2) - q.*m(1,2));
b16 = (f./q.^2).*(r.*m(3,3) - q.*m(1,3));

b21 = (f./q.^2).*(s.*(-m(3,3).*deltaY + m(3,2).*deltaZ) - q.*(-m(2,3).*deltaY + m(2,2).*deltaZ));
b22 = (f./q.^2).*(s.*(cosd(phi).*deltaX + sind(omega).*sind(phi).*deltaY - cosd(omega).*sind(phi).*deltaZ) - ...
       q.*(sind(phi).*sind(kapa).*deltaX - sind(omega).*cosd(phi).*sind(kapa).*deltaY + cosd(omega).*cosd(phi).*sind(kapa).*deltaZ));
b23 = (f./q).*(m(1,1).*deltaX + m(1,2).*deltaY + m(1,3).*deltaZ);
b24 = (f./q.^2).*(s.*m(3,1) - q.*m(2,1));
b25 = (f./q.^2).*(s.*m(3,2) - q.*m(2,2));
b26 = (f./q.^2).*(s.*m(3,3) - q.*m(2,3));

B = zeros(2*size(gcp,1),6);

for i = 1:size(gcp,1)

    B(2*i-1,:) = [b11(i) b12(i) b13(i) -b14(i) -b15(i) -b16(i)];
      B(2*i,:) = [b21(i) b22(i) b23(i) -b24(i) -b25(i) -b26(i)];

end

J = mphc(:,1) - (f.*(r./q));
K = mphc(:,2) - (f.*(s./q));

epsilon = zeros(2*size(J,1),1);
epsilon(1:2:end) = J;
epsilon(2:2:end) = K;

delta = inv(B'*B)*B'*epsilon;

omega = omega + (delta(1)*180/pi);
  phi = phi + (delta(2)*180/pi);
 kapa = kapa + (delta(3)*180/pi);

Xo = Xo + delta(4);
Yo = Yo + delta(5);
Zo = Zo + delta(6);

n = norm([delta(4:6)]);

num = 1;

while n >= p
    
    m(1,1) = cosd(phi)*cosd(kapa);
    m(1,2) = cosd(omega)*sind(kapa) + sind(omega)*sind(phi)*cosd(kapa);
    m(1,3) = sind(omega)*sind(kapa) - cosd(omega)*sind(phi)*cosd(kapa);
    m(2,1) = -cosd(phi)*sind(kapa);
    m(2,2) = cosd(omega)*cosd(kapa) - sind(omega)*sind(phi)*sind(kapa);
    m(2,3) = sind(omega)*cosd(kapa) + cosd(omega)*sind(phi)*sind(kapa);
    m(3,1) = sind(phi);
    m(3,2) = -sind(omega)*cosd(phi);
    m(3,3) = cosd(omega)*cosd(phi);
    
    deltaX = gcp(:,1) - Xo;
    deltaY = gcp(:,2) - Yo;
    deltaZ = gcp(:,3) - Zo;
    
    q = m(3,1).*deltaX + m(3,2).*deltaY + m(3,3).*deltaZ;
    r = m(1,1).*deltaX + m(1,2).*deltaY + m(1,3).*deltaZ;
    s = m(2,1).*deltaX + m(2,2).*deltaY + m(2,3).*deltaZ;
    
        
    b11 = (f./q.^2).*(r.*(-m(3,3).*deltaY+m(3,2).*deltaZ)-q.*(-m(1,3).*deltaY+m(1,2).*deltaZ));
    b12 = (f./q.^2).*(r.*(cosd(phi).*deltaX + sind(omega).*sind(phi).*deltaY - cosd(omega).*sind(phi).*deltaZ) - ...
    q.*(-sind(phi).*cosd(kapa).*deltaX + sind(omega).*cosd(phi).*cosd(kapa).*deltaY - cosd(omega).*cosd(phi).*cosd(kapa).*deltaZ));
    b13 = (-f./q).*(m(2,1).*deltaX + m(2,2).*deltaY + m(2,3).*deltaZ);
    b14 = (f./q.^2).*(r.*m(3,1) - q.*m(1,1));
    b15 = (f./q.^2).*(r.*m(3,2) - q.*m(1,2));
    b16 = (f./q.^2).*(r.*m(3,3) - q.*m(1,3));
    
    b21 = (f./q.^2).*(s.*(-m(3,3).*deltaY + m(3,2).*deltaZ) - q.*(-m(2,3).*deltaY + m(2,2).*deltaZ));
    b22 = (f./q.^2).*(s.*(cosd(phi).*deltaX + sind(omega).*sind(phi).*deltaY - cosd(omega).*sind(phi).*deltaZ) - ...
    q.*(sind(phi).*sind(kapa).*deltaX - sind(omega).*cosd(phi).*sind(kapa).*deltaY + cosd(omega).*cosd(phi).*sind(kapa).*deltaZ));
    b23 = (f./q).*(m(1,1).*deltaX + m(1,2).*deltaY + m(1,3).*deltaZ);
    b24 = (f./q.^2).*(s.*m(3,1) - q.*m(2,1));
    b25 = (f./q.^2).*(s.*m(3,2) - q.*m(2,2));
    b26 = (f./q.^2).*(s.*m(3,3) - q.*m(2,3));
    
    for i = 1:size(gcp,1)
        
        B(2*i-1,:) = [b11(i) b12(i) b13(i) -b14(i) -b15(i) -b16(i)];
          B(2*i,:) = [b21(i) b22(i) b23(i) -b24(i) -b25(i) -b26(i)];
        
    end

    J = mphc(:,1) - (f.*(r./q));
    K = mphc(:,2) - (f.*(s./q));
    
    epsilon(1:2:end) = J;
    epsilon(2:2:end) = K;
    
    delta = inv(B'*B)*B'*epsilon;
    
    omega = omega + (delta(1)*180/pi);
    phi = phi + (delta(2)*180/pi);
    kapa = kapa + (delta(3)*180/pi);
    
    Xo = Xo + delta(4);
    Yo = Yo + delta(5);
    Zo = Zo + delta(6);
    
    n = norm([delta(4:6)]);
    
    num = num + 1;

end

eoelements = [omega Xo;phi Yo;kapa Zo];