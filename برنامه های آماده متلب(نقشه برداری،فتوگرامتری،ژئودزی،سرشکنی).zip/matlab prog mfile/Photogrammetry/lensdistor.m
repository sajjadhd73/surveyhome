function [cphc F] = lensdistor(calib,f,mphc,n)

% in this function
%
% calib: CALIBbration data in form [alfa(in degree) delta_r(in mm)]
% f: focal length (in mm)
% mphp: Measured PHoto Coordinate
% n: polinomial order
%
% cphc: Carrected PHoto Coordinate
% F: polinomial Factors
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

 r = f*tand(calib(:,1));
dr = calib(:,2);

if n == 5

	A = [r r.^3 r.^5];
       
	F = inv(A'*A)*A'*dr;
    
    rx = sqrt(mphc(:,1).^2 + mphc(:,2).^2);
    Ax = [rx rx.^3 rx.^5];
    drx = Ax * F;
    
    cphx = mphc(:,1) .* (1 + (drx ./ rx));
    cphy = mphc(:,2) .* (1 + (drx ./ rx));
    
    cphc = [cphx cphy];
    
    m = min(r) :.1: max(r);
    poly = polyfit(r,dr,5);
    n = (poly(1)* m.^5) + (poly(2)* m.^4) + (poly(3)* m.^3) + (poly(4)* m.^2) + (poly(5)* m) + poly(6);
    
    plot(m,n)
    
elseif n == 7
    
    A = [r r.^3 r.^5 r.^7];
       
	F = inv(A'*A)*A'*dr;
    
    rx = sqrt(mphc(:,1).^2 + mphc(:,2).^2);
    Ax = [rx rx.^3 rx.^5 rx.^7];
    drx = Ax * F;
    
    cphx = mphc(:,1) .* (1 + (drx ./ rx));
    cphy = mphc(:,2) .* (1 + (drx ./ rx));
    
    cphc = [cphx cphy];
    
    m = min(r) :.1: max(r);
    poly = polyfit(r,dr,7);
    n = (poly(1)* m.^7) + (poly(2)* m.^6) + (poly(3)* m.^5) + (poly(4)* m.^4) + (poly(5)* m.^3) + (poly(6)* m.^2) + (poly(7)* m) + poly(8);
    
    plot(m,n)
    
else
    
    error('n can be only 5 and 7!');
    
end       