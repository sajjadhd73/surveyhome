function cphc = arefract(H,f,h,mphc)

% in this function
%
% H: flight Height (in km)
% f: Focal distance (in mm)
% h: ground height (in km)
% mphc: Measured Photo Coordinate (in mm)
%
% cphc: Corrected Photo Coordinate (in mm)
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

K = ((2410*H/(H^2 - 6*H + 250)) - (2410*h^2/((H^2 - 6*H + 250)*H))) / 1000000;

r = sqrt(mphc(:,1).^2 + mphc(:,2).^2);

beta = atan(r/f);
epsi = (K*r) / (f*1000000);

rc = f*tan(beta-epsi);

cphx = rc * mphc(:,1) ./ r;
cphy = rc * mphc(:,2) ./ r;

cphc = [cphx cphy];