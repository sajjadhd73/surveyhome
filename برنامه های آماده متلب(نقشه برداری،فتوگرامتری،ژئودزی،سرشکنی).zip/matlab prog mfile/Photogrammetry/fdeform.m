function [cphc F] = fdeform(cfc,mfc,mphp,method)

% in this function
%
%  cfc: calibrated fidushal coordinates
%  mfc: measured fidushal coordinates
% mphp: measured photo coordinates
%
% cphx: calibrated photo x-ordinate
% cphy: calibrated photo y-ordinate
%
% this funcion has been wrighted for 'MATLAB in Surveying' book.

switch lower(method)
    
    case 'uniform'
        
        A = zeros(4);
        B = zeros(4,1);
        
        for i = 1:2
    
            A(2*i-1,:) = [mfc(i,1) mfc(i,2) 1 0];
              A(2*i,:) = [mfc(i,2) -mfc(i,1) 0 1];
    
        end
        
        for i = 1:2
            
            B(2*i-1,:) = cfc(i,1);
              B(2*i,:) = cfc(i,2);
            
        end
        
        F = inv(A'*A)*A'*B;

        for i = 1:size(mphp,1)
            
            A(2*i-1,:) = [mphp(i,1) mphp(i,2) 1 0];
              A(2*i,:) = [mphp(i,2) -mphp(i,1) 0 1];
              
        end
        
        X = A*F;
        
        cphx = X(1:2:end);
        cphy = X(2:2:end);
        
        cphc = [cphx cphy];
        
    case 'nonuniform'

        A = zeros(6);
        B = zeros(6,1);
        
        for i = 1:3
    
            A(2*i-1,:) = [mfc(i,1) mfc(i,2) 0 0 1 0];
              A(2*i,:) = [0 0 mfc(i,1) mfc(i,2) 0 1];
    
        end
        
        for i = 1:3
            
            B(2*i-1,:) = cfc(i,1);
            B(2*i,:) = cfc(i,2);
            
        end
        
        F = inv(A'*A)*A'*B;

        for i = 1:size(mphp,1)
            
            A(2*i-1,:) = [mphp(i,1) mphp(i,2) 0 0 1 0];
              A(2*i,:) = [0 0 mphp(i,1) mphp(i,2) 0 1];
              
        end
        
        mphp = A*F;
        
        cphx = mphp(1:2:end);
        cphy = mphp(2:2:end);
        
        cphc = [cphx cphy];
        
    case 'unregular'
        
        A = zeros(8);
        B = zeros(8,1);
        
        for i = 1:4
    
            A(2*i-1,:) = [1 mfc(i,1) mfc(i,2) mfc(i,1)*mfc(i,2) 0 0 0 0];
              A(2*i,:) = [0 0 0 0 1 mfc(i,1) mfc(i,2) mfc(i,1)*mfc(i,2)];
    
        end
        
        for i = 1:4
            
            B(2*i-1,:) = cfc(i,1);
            B(2*i,:) = cfc(i,2);
            
        end
        
        F = inv(A'*A)*A'*B;

        for i = 1:size(mphp,1)
            
            A(2*i-1,:) = [1 mphp(i,1) mphp(i,2) mphp(i,1)*mphp(i,2) 0 0 0 0];
              A(2*i,:) = [0 0 0 0 1 mphp(i,1) mphp(i,2) mphp(i,1)*mphp(i,2)];
              
        end
        
        mphp = A*F;
        
        cphx = mphp(1:2:end);
        cphy = mphp(2:2:end);
        
        cphc = [cphx cphy];
end